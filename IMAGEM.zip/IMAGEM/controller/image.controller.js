const imgUpload = (req,res)=>{
    console.log(req.file);
    res.json({message:"Image uploaded",file:req.file})
    
}

module.exports={imgUpload}